(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n<router-outlet></router-outlet>\n<app-footer></app-footer>\n\n\n\n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/footer/footer.component.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/footer/footer.component.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"footer alert-dark\">All Rights are Reserved</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/core/header/header.component.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/core/header/header.component.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header bg-info\">\n<div class=\"logo\"><h3>MediBooks</h3></div>\n<!--<form class=\"form-inline justify-content-end mt-1\" *ngIf=\"preLogin\" (ngSubmit)=\"onSubmit()\">\n    <div class=\"form-group mb-2\">\n      <input type=\"text\"  class=\"form-control form-control-sm\" id=\"username\" placeholder=\"Username\" required maxlength=\"16\">\n    </div>\n    <div class=\"form-group mx-sm-3 mb-2\">\n      <input type=\"password\" class=\"form-control form-control-sm\" id=\"password\" placeholder=\"Password\" required maxlength=\"16\">\n    </div>\n    <button type=\"submit\" class=\"btn btn-outline-light btn-sm mb-2\">Login</button>\n  </form>-->\n  <nav class=\"navbar navbar-expand navbar-dark bg-dark\" *ngIf=\"currentUser\">\n        <div class=\"navbar-nav\">\n            <a class=\"nav-item nav-link\" routerLink=\"/\">Home</a>\n            <a class=\"nav-item nav-link\" (click)=\"logout()\">Logout</a>\n        </div>\n    </nav>\n<ul class=\"nav justify-content-end\" *ngIf=\"isLoggin\">\n    <li class=\"nav-item dropdown\">\n        <a class=\"nav-link  text-light\" [routerLink]=\"'/profile'\" >\n            <fa name=\"user-circle\" ></fa> my page \n        </a>\n    </li>\n    <li class=\"nav-item \">\n        <a class=\"nav-link  text-light\" [routerLink]=\"'/home'\">\n            <fa name=\"home\" ></fa> Home \n        </a>\n    </li>\n    <li class=\"nav-item \">\n        <a class=\"nav-link text-light\" [routerLink]=\"'/create'\" >\n            <fa name=\"plus-circle\" ></fa> Create \n        </a>\n    </li>\n    <li class=\"nav-item\">\n        <a class=\"nav-link text-light\"  >\n            <fa name=\"bell\" ></fa> \n        </a>\n    </li>\n        <li class=\"nav-item dropdown\">\n            <a class=\"nav-link dropdown-toggle text-light\" href=\"#\" id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                    <fa name=\"user-circle\" ></fa> {{userDetails.username}} \n            </a>\n            <div class=\"dropdown-menu overrite-dropdown\" aria-labelledby=\"navbarDropdownMenuLink\">\n                <button type=\"button\" class=\"btn btn-info  w-100\" [routerLink]=\"'/'\"> Logout </button>\n            </div>\n          </li>\n      </ul>\n    </div> \n "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.component.html":
/*!********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid pt-8\">\n    <div class=\"row mt-4\">\n        <div class=\"col-md-2 col-xs-12\">\n               <div>Shortcut Link</div>  \n                    \n                        \n        </div>\n        <div class=\"col-md-7 col-xs-12\">\n                <form #demoForm=\"ngForm\" >\n                        <file-upload [(ngModel)]=\"uploadedFiles\" class=\"minHeight100\"  name=\"files\" ></file-upload>\n                </form>\n                <div>\n                    <img [src]=\"localGoogle\" *ngIf=\"localPDF\" class=\"imgPlaceholder\">\n                    <ngx-doc-viewer [url]=\"localGoogle\" viewer=\"google\" style=\"width:100%;height:50vh;\"></ngx-doc-viewer></div>\n\n                <div>\n                  <img [src]=\"localOffice\" *ngIf=\"localIMG\" class=\"imgPlaceholder\">\n                  <ngx-doc-viewer [url]=\"localOffice\" viewer=\"office\" style=\"width:100%;height:50vh;\"></ngx-doc-viewer></div>\n                  \n        </div>\n        <div class=\"col-md-3 col-xs-12\">\n            <h4>Live Chat </h4>\n        </div>\n    </div>\n</div>\n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/prelogin/pre-details/pre-details.component.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/prelogin/pre-details/pre-details.component.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"card w-20 mr-1 mb-1 pt-2 text-center\" *ngFor=\"let prelogin of preLoginDetails\">\n    <fa name=\"{{prelogin.icon}} fa-3x\" ></fa>  \n    <div class=\"card-body p-75rem\">\n        <h6 class=\"card-title\">{{prelogin.heading}}</h6>\n        <p class=\"card-text card-para small mb-0\">\n            {{prelogin.subText}}\n        </p>\n        <button type=\"button\" class=\"btn btn-link btn-sm float-right\" [routerLink]=\"removeWhiteSpace(prelogin.heading)\" (click)=\"proLoginContent(prelogin.heading)\" >More</button>\n    </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/prelogin/pre-login-desc/pre-login-desc.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/prelogin/pre-login-desc/pre-login-desc.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid mt-10\">\n    <div class=\"row\">\n        <div *ngFor=\"let proLoginDesc of preLoginDescriptNext\" class=\"col-md-12 col-12\">\n            <div class=\"col-md-3 col-3 float-left\"><img class=\"imgSizeFix\" src=\"{{proLoginDesc.img}}\" alt=\"{{proLoginDesc.heading}}\" /></div>\n            <div class=\"col-md-9 col- float-left\">\n                <h5 class=\"bg-secondary  p-3 text-white\" >  {{proLoginDesc.heading}} </h5>\n                <p class=\"text-md-indent\">{{proLoginDesc.content}}</p>\n            </div>\n        </div>\n        <button class=\"btn btn-secondary fs-14 posFixBot float-right \" routerLink=\"/\"  role=\"button\">Back</button>\n    </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/prelogin/prelogin.component.html":
/*!****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/prelogin/prelogin.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid pt-8\">\n    <div class=\"row mt-2\">\n        <div class=\"col-md-8 col-xs-12\" id=\"storyShort\"> \n                <app-pre-details ></app-pre-details>\n        </div>\n        <div class=\"col-md-4 col-xs-12\"> \n                <nav>\n                <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">\n                        <a class=\"nav-item nav-link active\" id=\"nav-login-tab\" data-toggle=\"tab\" href=\"#nav-login\" role=\"tab\" aria-controls=\"nav-login\" aria-selected=\"true\">Sign In</a>\n                        <a class=\"nav-item nav-link\" id=\"nav-register-tab\" data-toggle=\"tab\" href=\"#nav-register\" role=\"tab\" aria-controls=\"nav-register\" aria-selected=\"false\">Register</a>\n                </div>\n                </nav>                     \n                <div class=\"tab-content\" id=\"nav-tabContent\">\n                <app-signin  class=\"tab-pane fade show ml-4 mt-2 active\" id=\"nav-login\" role=\"tabpanel\" aria-labelledby=\"nav-login-tab\"></app-signin>\n                <app-signup class=\"tab-pane fade ml-4 mt-4\" id=\"nav-register\" role=\"tabpanel\" aria-labelledby=\"nav-register-tab\"></app-signup>                       \n                </div>\n        </div>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/prelogin/signin/signin.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/prelogin/signin/signin.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form  [formGroup]=\"postForm\" (ngSubmit)=\"submit()\">\n    <div class=\"form-group\">\n            <label for=\"logInput\" class=\"col-form-label-sm\">User Name</label>\n            <input type=\"email\" formControlName=\"username\" class=\"form-control form-control-sm \" [ngClass]=\"{ 'is-invalid': submitted && lForm.username.errors }\" id=\"username\" aria-describedby=\"emailHelp\" placeholder=\"Enter email\" required />\n            <div *ngIf=\"submitted && lForm.username.errors\" class=\"invalid-feedback\">\n                    <div *ngIf=\"lForm.username.errors.required\">Username is required</div>\n            </div>\n    </div>\n    <div class=\"form-group\">\n            <label for=\"logPassword\" class=\"col-form-label-sm\">Password</label>\n            <input type=\"password\" formControlName=\"password\" class=\"form-control form-control-sm\" [ngClass]=\"{ 'is-invalid': submitted && lForm.password.errors }\" id=\"password\" placeholder=\"Password\" required>\n            <div *ngIf=\"submitted && lForm.password.errors\" class=\"invalid-feedback\">\n                    <div *ngIf=\"lForm.password.errors.required\">Password is required</div>\n            </div>\n    </div>\n    <div class=\"form-check\">\n            <input type=\"checkbox\" class=\"form-check-input form-control-sm\" id=\"fp\">\n            <label class=\"form-check-label col-form-label-sm forgetPass\" for=\"fp\">Forget Password</label>\n    </div>\n    <button type=\"submit\" class=\"btn btn-sm float-right mt-2 btn-primary\">Log In</button>\n</form>\n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/prelogin/signup/signup.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/prelogin/signup/signup.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"form-row\">\n    <div class=\"form-group col-md-6\">\n    <input type=\"text\" class=\"form-control form-control-sm\" id=\"firstName\" placeholder=\"First Name\">\n    </div>\n    <div class=\"form-group col-md-6\">\n    <input type=\"text\" class=\"form-control form-control-sm\" id=\"lastName\" placeholder=\"Last Name\">\n    </div>\n</div>\n<div class=\"form-row\">\n    <div class=\"form-group col-md-6\">\n            <input type=\"password\" class=\"form-control form-control-sm\" id=\"rpassword\" placeholder=\"Password\">\n    </div>\n    <div class=\"form-group col-md-6\">\n            <input type=\"password\" class=\"form-control form-control-sm\" id=\"rconfirmPassword\" placeholder=\"Confirm Password\">\n    </div>\n</div>\n<div class=\"form-row\">\n     <div class=\"form-group col-md-6\">\n            <input type=\"email\" class=\"form-control form-control-sm\" id=\"email\" placeholder=\"Email\">\n    </div>\n    <div class=\"form-group col-md-6\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"phoneNumber\" placeholder=\"Phone\">\n    </div>\n</div>\n\n<div class=\"form-row\">\n    <div class=\"form-group col-md-4\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"dob\" placeholder=\"Date Of Birth\">\n    </div>\n    <div class=\"form-group col-md-2\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"age\" placeholder=\"Age\">\n    </div>\n    <div class=\"form-group col-md-6\">\n            <select id=\"state\" class=\"form-control form-control-sm\"  (change)=\"optionChange($event)\" >\n                    <option *ngFor=\"let design of designation;  let i = index\" #selectedValue value=\"design\" [selected]=\"i == 0\">{{design}}</option>\n            </select>\n    </div>\n</div>\n<div class=\"form-row\" *ngIf=\"selectedValues == 'Doctor'\">\n    <div class=\"form-group col-md-4\" >\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"regno\" placeholder=\"Government Register No.\">\n    </div>\n    <div class=\"form-group col-md-4\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"studied\" placeholder=\"Medical Education\">\n    </div>\n    <div class=\"form-group col-md-4\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"Departments\" placeholder=\"Department Specialist\">\n    </div>\n</div>\n<div class=\"form-row\">\n     <div class=\"form-group col-md-6\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"addressLine\" placeholder=\"1234 Main St\">\n    </div>\n    <div class=\"form-group col-md-6\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"addressLine2\" placeholder=\"Apartment, studio, or floor\">\n    </div>\n</div>\n<div class=\"form-row\">\n    <div class=\"form-group col-md-4\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"city\" placeholder=\"City\">\n    </div>\n    <div class=\"form-group col-md-5\">\n            <select id=\"state\" class=\"form-control form-control-sm\" >\n                    <option selected>Choose State</option>\n                    <option>...</option>\n            </select>\n    </div>\n    <div class=\"form-group col-md-3\">\n            <input type=\"text\" class=\"form-control form-control-sm\" id=\"zipCode\" placeholder=\"Zip Code\">\n    </div>\n</div>\n<button type=\"submit\" class=\"btn btn-sm btn-primary float-right mt-2\">Register</button> \n"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule, RoutingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoutingComponent", function() { return RoutingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _prelogin_prelogin_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./prelogin/prelogin.component */ "./src/app/prelogin/prelogin.component.ts");
/* harmony import */ var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-not-found/page-not-found.component */ "./src/app/page-not-found/page-not-found.component.ts");
/* harmony import */ var _prelogin_pre_login_desc_pre_login_desc_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./prelogin/pre-login-desc/pre-login-desc.component */ "./src/app/prelogin/pre-login-desc/pre-login-desc.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");







const routes = [
    { path: '', component: _prelogin_prelogin_component__WEBPACK_IMPORTED_MODULE_3__["PreloginComponent"], pathMatch: 'full' },
    { path: 'home', component: _home_home_component__WEBPACK_IMPORTED_MODULE_6__["HomeComponent"] },
    { path: ':id', component: _prelogin_pre_login_desc_pre_login_desc_component__WEBPACK_IMPORTED_MODULE_5__["PreLoginDescComponent"] },
    //{ path: 'products/:id', component: ProductsComponent } ,
    { path: '**', component: _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_4__["PageNotFoundComponent"] }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);

const RoutingComponent = [_prelogin_prelogin_component__WEBPACK_IMPORTED_MODULE_3__["PreloginComponent"], _prelogin_pre_login_desc_pre_login_desc_component__WEBPACK_IMPORTED_MODULE_5__["PreLoginDescComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_6__["HomeComponent"], _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_4__["PageNotFoundComponent"]];


/***/ }),

/***/ "./src/app/app.component.pipe.ts":
/*!***************************************!*\
  !*** ./src/app/app.component.pipe.ts ***!
  \***************************************/
/*! exports provided: AppComponentPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponentPipe", function() { return AppComponentPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");



let AppComponentPipe = class AppComponentPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(html) {
        return this.sanitizer.bypassSecurityTrustHtml(html);
    }
};
AppComponentPipe.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] }
];
AppComponentPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({ name: 'removeSpace' })
], AppComponentPipe);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AppComponent = class AppComponent {
    constructor() { }
    ngOnInit() { }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
        styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: tokenGetter, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tokenGetter", function() { return tokenGetter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _iplab_ngx_file_upload__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @iplab/ngx-file-upload */ "./node_modules/@iplab/ngx-file-upload/fesm2015/iplab-ngx-file-upload.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm2015/animations.js");
/* harmony import */ var angular_font_awesome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-font-awesome */ "./node_modules/angular-font-awesome/dist/angular-font-awesome.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _core_header_header_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/header/header.component */ "./src/app/core/header/header.component.ts");
/* harmony import */ var _core_footer_footer_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./core/footer/footer.component */ "./src/app/core/footer/footer.component.ts");
/* harmony import */ var ngx_doc_viewer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-doc-viewer */ "./node_modules/ngx-doc-viewer/fesm2015/ngx-doc-viewer.js");
/* harmony import */ var _prelogin_prelogin_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./prelogin/prelogin.component */ "./src/app/prelogin/prelogin.component.ts");
/* harmony import */ var _prelogin_pre_login_desc_pre_login_desc_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./prelogin/pre-login-desc/pre-login-desc.component */ "./src/app/prelogin/pre-login-desc/pre-login-desc.component.ts");
/* harmony import */ var _app_component_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./app.component.pipe */ "./src/app/app.component.pipe.ts");
/* harmony import */ var _prelogin_signin_signin_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./prelogin/signin/signin.component */ "./src/app/prelogin/signin/signin.component.ts");
/* harmony import */ var _prelogin_signup_signup_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./prelogin/signup/signup.component */ "./src/app/prelogin/signup/signup.component.ts");
/* harmony import */ var _shared_auth_guard__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./shared/auth.guard */ "./src/app/shared/auth.guard.ts");
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @auth0/angular-jwt */ "./node_modules/@auth0/angular-jwt/index.js");
/* harmony import */ var _prelogin_pre_details_pre_details_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./prelogin/pre-details/pre-details.component */ "./src/app/prelogin/pre-details/pre-details.component.ts");





















function tokenGetter() {
    return localStorage.getItem('access_token');
}
let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"],
            _core_header_header_component__WEBPACK_IMPORTED_MODULE_10__["HeaderComponent"],
            _core_footer_footer_component__WEBPACK_IMPORTED_MODULE_11__["FooterComponent"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["RoutingComponent"],
            _prelogin_prelogin_component__WEBPACK_IMPORTED_MODULE_13__["PreloginComponent"],
            _prelogin_pre_login_desc_pre_login_desc_component__WEBPACK_IMPORTED_MODULE_14__["PreLoginDescComponent"],
            _app_component_pipe__WEBPACK_IMPORTED_MODULE_15__["AppComponentPipe"],
            _prelogin_signin_signin_component__WEBPACK_IMPORTED_MODULE_16__["SigninComponent"],
            _prelogin_signup_signup_component__WEBPACK_IMPORTED_MODULE_17__["SignupComponent"],
            _prelogin_pre_details_pre_details_component__WEBPACK_IMPORTED_MODULE_20__["PreDetailsComponent"]
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _iplab_ngx_file_upload__WEBPACK_IMPORTED_MODULE_4__["FileUploadModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__["BrowserAnimationsModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
            angular_font_awesome__WEBPACK_IMPORTED_MODULE_6__["AngularFontAwesomeModule"],
            ngx_doc_viewer__WEBPACK_IMPORTED_MODULE_12__["NgxDocViewerModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_19__["JwtModule"].forRoot({
                config: {
                    tokenGetter: tokenGetter,
                    whitelistedDomains: ['localhost:4000'],
                    blacklistedRoutes: ['localhost:4000/api/auth']
                }
            })
        ],
        providers: [_shared_auth_guard__WEBPACK_IMPORTED_MODULE_18__["AuthGuard"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["CUSTOM_ELEMENTS_SCHEMA"]],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]],
        entryComponents: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/core/footer/footer.component.scss":
/*!***************************************************!*\
  !*** ./src/app/core/footer/footer.component.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".footer {\n  text-align: left;\n  border-radius: 0;\n  position: fixed;\n  bottom: 0;\n  width: 100vw;\n  padding: 0.75rem 1.25rem;\n  border: 1px solid transparent;\n  z-index: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29yZS9mb290ZXIvRDpcXG15LXByb2plY3RcXG1lZGktYm9va3Mvc3JjXFxhcHBcXGNvcmVcXGZvb3RlclxcZm9vdGVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb3JlL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0VBQ0Esd0JBQUE7RUFDQSw2QkFBQTtFQUNBLFVBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2NvcmUvZm9vdGVyL2Zvb3Rlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mb290ZXJ7XHJcbiAgICB0ZXh0LWFsaWduOmxlZnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOjA7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBib3R0b206MDtcclxuICAgIHdpZHRoOjEwMHZ3O1xyXG4gICAgcGFkZGluZzogLjc1cmVtIDEuMjVyZW07XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgIHotaW5kZXg6MVxyXG59IiwiLmZvb3RlciB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGJvcmRlci1yYWRpdXM6IDA7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgYm90dG9tOiAwO1xuICB3aWR0aDogMTAwdnc7XG4gIHBhZGRpbmc6IDAuNzVyZW0gMS4yNXJlbTtcbiAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIHotaW5kZXg6IDE7XG59Il19 */"

/***/ }),

/***/ "./src/app/core/footer/footer.component.ts":
/*!*************************************************!*\
  !*** ./src/app/core/footer/footer.component.ts ***!
  \*************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FooterComponent = class FooterComponent {
    constructor() { }
    ngOnInit() {
    }
};
FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-footer',
        template: __webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/footer/footer.component.html"),
        styles: [__webpack_require__(/*! ./footer.component.scss */ "./src/app/core/footer/footer.component.scss")]
    })
], FooterComponent);



/***/ }),

/***/ "./src/app/core/header/header.component.scss":
/*!***************************************************!*\
  !*** ./src/app/core/header/header.component.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".logo {\n  float: left;\n  color: #FFF;\n}\n\n.overrite-dropdown {\n  background: none !important;\n  border: none !important;\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.header {\n  border-radius: 0;\n  position: fixed;\n  top: 0;\n  width: 100vw;\n  padding: 5px 20px 5px 20px;\n  border: 1px solid transparent;\n  z-index: 2;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29yZS9oZWFkZXIvRDpcXG15LXByb2plY3RcXG1lZGktYm9va3Mvc3JjXFxhcHBcXGNvcmVcXGhlYWRlclxcaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb3JlL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxXQUFBO0VBQ0EsV0FBQTtBQ0FGOztBREVBO0VBQ0UsMkJBQUE7RUFDQSx1QkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0JBQUE7QUNDRjs7QURDQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLE1BQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSw2QkFBQTtFQUNBLFVBQUE7QUNFRiIsImZpbGUiOiJzcmMvYXBwL2NvcmUvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuLmxvZ297XG4gIGZsb2F0OmxlZnQ7XG4gIGNvbG9yOiNGRkY7XG59XG4ub3ZlcnJpdGUtZHJvcGRvd257XG4gIGJhY2tncm91bmQ6bm9uZSAhaW1wb3J0YW50O1xuICBib3JkZXI6bm9uZSAhaW1wb3J0YW50O1xuICBwYWRkaW5nOjAgIWltcG9ydGFudDtcbiAgbWFyZ2luOjAgIWltcG9ydGFudDtcbn1cbi5oZWFkZXJ7XG4gIGJvcmRlci1yYWRpdXM6MDtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB0b3A6MDtcbiAgd2lkdGg6MTAwdnc7XG4gIHBhZGRpbmc6NXB4IDIwcHggNXB4IDIwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICB6LWluZGV4OjJcbn1cbiIsIi5sb2dvIHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIGNvbG9yOiAjRkZGO1xufVxuXG4ub3ZlcnJpdGUtZHJvcGRvd24ge1xuICBiYWNrZ3JvdW5kOiBub25lICFpbXBvcnRhbnQ7XG4gIGJvcmRlcjogbm9uZSAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xufVxuXG4uaGVhZGVyIHtcbiAgYm9yZGVyLXJhZGl1czogMDtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB0b3A6IDA7XG4gIHdpZHRoOiAxMDB2dztcbiAgcGFkZGluZzogNXB4IDIwcHggNXB4IDIwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICB6LWluZGV4OiAyO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/core/header/header.component.ts":
/*!*************************************************!*\
  !*** ./src/app/core/header/header.component.ts ***!
  \*************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/common.service */ "./src/app/core/services/common.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");




let HeaderComponent = class HeaderComponent {
    constructor(common, router) {
        this.common = common;
        this.router = router;
        this.preLogin = true;
        this.isLoggin = false;
    }
    ngOnInit() {
        this.common.getProfileInfo().subscribe(data => {
            console.log('profile data', data);
            this.userDetails = data;
        });
    }
};
HeaderComponent.ctorParameters = () => [
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__["CommonService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-header',
        template: __webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/index.js!./src/app/core/header/header.component.html"),
        styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/core/header/header.component.scss")]
    })
], HeaderComponent);



/***/ }),

/***/ "./src/app/core/services/common.service.ts":
/*!*************************************************!*\
  !*** ./src/app/core/services/common.service.ts ***!
  \*************************************************/
/*! exports provided: CommonService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonService", function() { return CommonService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");



let CommonService = class CommonService {
    constructor() {
        this.profileInfo = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.orderInfo = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('orderList');
        this.productId = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('productId');
        this.preLoginHeading = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('preLoginHeading');
        this.preLoginDetailsNext = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('preLoginDetailsNext');
    }
    setProfileInfo(value) {
        this.profileInfo.next(value);
    }
    setPreLogin(value) {
        this.preLoginHeading.next(value);
    }
    setPreLoginDetails(value) {
        this.preLoginDetailsNext.next(value);
    }
    getProfileInfo() {
        return this.profileInfo.asObservable();
    }
    getPreLoginDetails() {
        return this.preLoginDetailsNext.asObservable();
    }
};
CommonService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CommonService);



/***/ }),

/***/ "./src/app/home/home.component.scss":
/*!******************************************!*\
  !*** ./src/app/home/home.component.scss ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "agm-map {\n  margin-top: 25px;\n  height: 300px;\n  width: 400px;\n}\n\n.profileText {\n  word-break: break-all;\n  margin-bottom: 15px;\n}\n\n.minHeight100 {\n  min-height: 100px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9EOlxcbXktcHJvamVjdFxcbWVkaS1ib29rcy9zcmNcXGFwcFxcaG9tZVxcaG9tZS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQ0NKOztBRENBO0VBQ0kscUJBQUE7RUFDQSxtQkFBQTtBQ0VKOztBREFBO0VBQ0ksNEJBQUE7QUNHSiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImFnbS1tYXAge1xyXG4gICAgbWFyZ2luLXRvcDoyNXB4O1xyXG4gICAgaGVpZ2h0OiAzMDBweDtcclxuICAgIHdpZHRoOjQwMHB4O1xyXG59XHJcbi5wcm9maWxlVGV4dHtcclxuICAgIHdvcmQtYnJlYWs6YnJlYWstYWxsOyBcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHhcclxufVxyXG4ubWluSGVpZ2h0MTAwe1xyXG4gICAgbWluLWhlaWdodDogMTAwcHggISBpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbiIsImFnbS1tYXAge1xuICBtYXJnaW4tdG9wOiAyNXB4O1xuICBoZWlnaHQ6IDMwMHB4O1xuICB3aWR0aDogNDAwcHg7XG59XG5cbi5wcm9maWxlVGV4dCB7XG4gIHdvcmQtYnJlYWs6IGJyZWFrLWFsbDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cblxuLm1pbkhlaWdodDEwMCB7XG4gIG1pbi1oZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/services/http-service.service */ "./src/app/shared/services/http-service.service.ts");
/* harmony import */ var _core_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../core/services/common.service */ "./src/app/core/services/common.service.ts");




let HomeComponent = class HomeComponent {
    constructor(httpRecived, common) {
        this.httpRecived = httpRecived;
        this.common = common;
        this.users = [];
        this.uploadedFiles = [];
        this.profileListAcc = {};
        this.proName = {};
    }
    ngOnInit() {
        this.getProfileList();
    }
    clear() {
        this.uploadedFiles = [];
    }
    showPreviewImage(event) {
        if (event.target.files && event.target.files[0]) {
            var reader = new FileReader();
            reader.onload = (event) => {
                this.localOffice = event.target.result;
            };
            reader.readAsDataURL(event.target.files[0]);
            this.localIMG = event.target.files[0];
        }
    }
    showPreviewPdf(event) {
        if (event.target.files && event.target.files[0]) {
            var reader = new FileReader();
            reader.onload = (event) => {
                this.localGoogle = event.target.result;
            };
            reader.readAsDataURL(event.target.files[0]);
            this.localPDF = event.target.files[0];
        }
    }
    getProfileList() {
        this.httpRecived.getHttpRequest().subscribe(data => {
            this.profileListAcc = data;
            this.common.setProfileInfo(this.profileListAcc);
        }, err => console.error(err));
    }
};
HomeComponent.ctorParameters = () => [
    { type: _shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_2__["HttpServiceService"] },
    { type: _core_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"] }
];
HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: __webpack_require__(/*! raw-loader!./home.component.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.component.html"),
        styles: [__webpack_require__(/*! ./home.component.scss */ "./src/app/home/home.component.scss")]
    })
], HomeComponent);



/***/ }),

/***/ "./src/app/page-not-found/page-not-found.component.ts":
/*!************************************************************!*\
  !*** ./src/app/page-not-found/page-not-found.component.ts ***!
  \************************************************************/
/*! exports provided: PageNotFoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageNotFoundComponent", function() { return PageNotFoundComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let PageNotFoundComponent = class PageNotFoundComponent {
    constructor() { }
    ngOnInit() {
    }
};
PageNotFoundComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-page-not-found',
        template: `
    <p>
      page-not-found works!
    </p>
  `
    })
], PageNotFoundComponent);



/***/ }),

/***/ "./src/app/prelogin/pre-details/pre-details.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/prelogin/pre-details/pre-details.component.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZWxvZ2luL3ByZS1kZXRhaWxzL3ByZS1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/prelogin/pre-details/pre-details.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/prelogin/pre-details/pre-details.component.ts ***!
  \***************************************************************/
/*! exports provided: PreDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreDetailsComponent", function() { return PreDetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/http-service.service */ "./src/app/shared/services/http-service.service.ts");
/* harmony import */ var _core_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/services/common.service */ "./src/app/core/services/common.service.ts");





let PreDetailsComponent = class PreDetailsComponent {
    constructor(route, router, loginPage, commons) {
        this.route = route;
        this.router = router;
        this.loginPage = loginPage;
        this.commons = commons;
        this.preLoginDetails = [];
        this.dataSaved = false;
    }
    ngOnInit() {
        this.getProfileList();
    }
    getProfileList() {
        this.loginPage.getLoginPageRequest().subscribe(data => {
            this.preLoginDetails = data;
        }, err => console.error(err));
    }
    proLoginContent(preLogHead) {
        this.commons.setPreLogin(preLogHead);
    }
    removeWhiteSpace(url) {
        return url && url.replace(/[\r\n\t\f\s]/gi, "");
    }
};
PreDetailsComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_3__["HttpServiceService"] },
    { type: _core_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"] }
];
PreDetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pre-details',
        template: __webpack_require__(/*! raw-loader!./pre-details.component.html */ "./node_modules/raw-loader/index.js!./src/app/prelogin/pre-details/pre-details.component.html"),
        styles: [__webpack_require__(/*! ./pre-details.component.scss */ "./src/app/prelogin/pre-details/pre-details.component.scss")]
    })
], PreDetailsComponent);



/***/ }),

/***/ "./src/app/prelogin/pre-login-desc/pre-login-desc.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/prelogin/pre-login-desc/pre-login-desc.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZWxvZ2luL3ByZS1sb2dpbi1kZXNjL3ByZS1sb2dpbi1kZXNjLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/prelogin/pre-login-desc/pre-login-desc.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/prelogin/pre-login-desc/pre-login-desc.component.ts ***!
  \*********************************************************************/
/*! exports provided: PreLoginDescComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreLoginDescComponent", function() { return PreLoginDescComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _core_services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/services/common.service */ "./src/app/core/services/common.service.ts");
/* harmony import */ var src_app_shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/http-service.service */ "./src/app/shared/services/http-service.service.ts");




let PreLoginDescComponent = class PreLoginDescComponent {
    constructor(commons, loginPage) {
        this.commons = commons;
        this.loginPage = loginPage;
        this.preLoginDesc = "";
        this.preLoginDescDetails = [];
        this.preLoginDescriptNext = [];
    }
    ngOnInit() {
        this.commons.preLoginHeading.subscribe(data => {
            this.preLoginDesc = data;
            this.getHttpPreLog(this.preLoginDesc);
        });
    }
    getHttpPreLog(preData) {
        this.loginPage.getLoginPageRequest().subscribe(data => {
            this.preLoginDescDetails = data;
            for (var preLog in this.preLoginDescDetails) {
                if (preData == this.preLoginDescDetails[preLog].heading) {
                    this.preLoginDescriptNext.push(this.preLoginDescDetails[preLog]);
                }
            }
        }, err => console.error(err));
    }
};
PreLoginDescComponent.ctorParameters = () => [
    { type: _core_services_common_service__WEBPACK_IMPORTED_MODULE_2__["CommonService"] },
    { type: src_app_shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_3__["HttpServiceService"] }
];
PreLoginDescComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pre-login-desc',
        template: __webpack_require__(/*! raw-loader!./pre-login-desc.component.html */ "./node_modules/raw-loader/index.js!./src/app/prelogin/pre-login-desc/pre-login-desc.component.html"),
        styles: [__webpack_require__(/*! ./pre-login-desc.component.scss */ "./src/app/prelogin/pre-login-desc/pre-login-desc.component.scss")]
    })
], PreLoginDescComponent);



/***/ }),

/***/ "./src/app/prelogin/prelogin.component.scss":
/*!**************************************************!*\
  !*** ./src/app/prelogin/prelogin.component.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZWxvZ2luL3ByZWxvZ2luLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/prelogin/prelogin.component.ts":
/*!************************************************!*\
  !*** ./src/app/prelogin/prelogin.component.ts ***!
  \************************************************/
/*! exports provided: PreloginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreloginComponent", function() { return PreloginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let PreloginComponent = class PreloginComponent {
    constructor() { }
    ngOnInit() {
    }
};
PreloginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-prelogin',
        template: __webpack_require__(/*! raw-loader!./prelogin.component.html */ "./node_modules/raw-loader/index.js!./src/app/prelogin/prelogin.component.html"),
        styles: [__webpack_require__(/*! ./prelogin.component.scss */ "./src/app/prelogin/prelogin.component.scss")]
    })
], PreloginComponent);



/***/ }),

/***/ "./src/app/prelogin/signin/signin.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/prelogin/signin/signin.component.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZWxvZ2luL3NpZ25pbi9zaWduaW4uY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/prelogin/signin/signin.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/prelogin/signin/signin.component.ts ***!
  \*****************************************************/
/*! exports provided: SigninComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninComponent", function() { return SigninComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/http-service.service */ "./src/app/shared/services/http-service.service.ts");






let SigninComponent = class SigninComponent {
    constructor(formBuilder, auth, router) {
        this.formBuilder = formBuilder;
        this.auth = auth;
        this.router = router;
    }
    ngOnInit() {
        this.postForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            username: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]()
        });
    }
    submit() {
        this.auth.login(this.username, this.password)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["first"])())
            .subscribe((results) => {
            this.userdetails = results;
            this.router.navigate(['home']);
        }, err => console.error(err));
    }
};
SigninComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _shared_services_http_service_service__WEBPACK_IMPORTED_MODULE_5__["HttpServiceService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
SigninComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-signin',
        template: __webpack_require__(/*! raw-loader!./signin.component.html */ "./node_modules/raw-loader/index.js!./src/app/prelogin/signin/signin.component.html"),
        styles: [__webpack_require__(/*! ./signin.component.scss */ "./src/app/prelogin/signin/signin.component.scss")]
    })
], SigninComponent);



/***/ }),

/***/ "./src/app/prelogin/signup/signup.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/prelogin/signup/signup.component.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZWxvZ2luL3NpZ251cC9zaWdudXAuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/prelogin/signup/signup.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/prelogin/signup/signup.component.ts ***!
  \*****************************************************/
/*! exports provided: SignupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupComponent", function() { return SignupComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let SignupComponent = class SignupComponent {
    constructor() {
        this.designation = [
            "Choose Designation", "Doctor", "Patient", "Pharmacy", "Diagnostic", "Hospital", "Medical World"
        ];
    }
    ngOnInit() {
    }
    optionChange(event) {
        for (var test in this.designation) {
            if (this.selectedValues == this.designation[this])
                this.selctedValues = this.selectedValues;
        }
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("selectedValue", { static: true })
], SignupComponent.prototype, "selectedValues", void 0);
SignupComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-signup',
        template: __webpack_require__(/*! raw-loader!./signup.component.html */ "./node_modules/raw-loader/index.js!./src/app/prelogin/signup/signup.component.html"),
        styles: [__webpack_require__(/*! ./signup.component.scss */ "./src/app/prelogin/signup/signup.component.scss")]
    })
], SignupComponent);



/***/ }),

/***/ "./src/app/shared/auth.guard.ts":
/*!**************************************!*\
  !*** ./src/app/shared/auth.guard.ts ***!
  \**************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let AuthGuard = class AuthGuard {
    constructor(router) {
        this.router = router;
    }
    canActivate(next, state) {
        //if (localStorage.getItem('access_token')) {
        //   return true;
        // }
        this.router.navigate(['']);
        return false;
    }
};
AuthGuard.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], AuthGuard);



/***/ }),

/***/ "./src/app/shared/services/http-service.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/shared/services/http-service.service.ts ***!
  \*********************************************************/
/*! exports provided: HttpServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpServiceService", function() { return HttpServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");




let HttpServiceService = class HttpServiceService {
    constructor(http) {
        this.http = http;
    }
    getHttpRequest() {
        return this.http.get('/profileList');
    }
    getLoginPageRequest() {
        return this.http.get('/preLogin');
    }
    getPostLogin(preLogin) {
        let httpHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/json'
        });
        return this.http.post('/postLogin', preLogin, { headers: httpHeaders, observe: 'response' });
    }
    login(username, password) {
        return this.http.post('/postLogin', { username: username, password: password })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(result => {
            result.user;
            //localStorage.setItem('access_token', result.token);
            return true;
        }));
    }
    logout() {
        localStorage.removeItem('access_token');
    }
    get loggedIn() {
        return (localStorage.getItem('access_token') !== null);
    }
};
HttpServiceService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
HttpServiceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], HttpServiceService);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\my-project\medi-books\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map